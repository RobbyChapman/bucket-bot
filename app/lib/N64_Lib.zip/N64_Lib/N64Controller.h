/**
* Created by robert.chapman on 4/21/16.
*/
#ifndef N64_CONTROLLER_H
#define N64_CONTROLLER_H

#include <stdint.h>

typedef struct
{
    bool a;
    bool b;
    int8_t x;
    int8_t y;
    bool z;
    bool start;
    bool cUp;
    bool cDown;
    bool cLeft;
    bool cRight;
    bool dUp;
    bool dDown;
    bool dLeft;
    bool dRight;
    bool leftBumper;
    bool rightBumper;
} N64Controller_t;

#endif
