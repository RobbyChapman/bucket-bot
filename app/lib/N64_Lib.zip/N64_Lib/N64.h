/**
* Created by robert.chapman on 4/21/16.
*/

#include "N64Controller.h"

class N64 {
  public:
    N64(int pin);
    void begin();
    N64Controller_t read();
};
